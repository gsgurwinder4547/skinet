import {
  MatDivider,
  MatDividerModule
} from "./chunk-Z3ACIIQM.js";
import "./chunk-RGD2AOC5.js";
import "./chunk-T5CW57YL.js";
import "./chunk-BHM4ONBH.js";
import "./chunk-MNDS4BZZ.js";
import "./chunk-KOABHM7R.js";
import "./chunk-4IFB7JBB.js";
import "./chunk-TJFVSI2U.js";
export {
  MatDivider,
  MatDividerModule
};
