import {
  __name
} from "./chunk-TJFVSI2U.js";

// node_modules/nanoid/url-alphabet/index.js
var urlAlphabet = "useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict";

// node_modules/nanoid/index.browser.js
var random = /* @__PURE__ */ __name((bytes) => crypto.getRandomValues(new Uint8Array(bytes)), "random");
var customRandom = /* @__PURE__ */ __name((alphabet, defaultSize, getRandom) => {
  let mask = (2 << Math.log2(alphabet.length - 1)) - 1;
  let step = -~(1.6 * mask * defaultSize / alphabet.length);
  return (size = defaultSize) => {
    let id = "";
    while (true) {
      let bytes = getRandom(step);
      let j = step | 0;
      while (j--) {
        id += alphabet[bytes[j] & mask] || "";
        if (id.length >= size) return id;
      }
    }
  };
}, "customRandom");
var customAlphabet = /* @__PURE__ */ __name((alphabet, size = 21) => customRandom(alphabet, size | 0, random), "customAlphabet");
var nanoid = /* @__PURE__ */ __name((size = 21) => {
  let id = "";
  let bytes = crypto.getRandomValues(new Uint8Array(size |= 0));
  while (size--) {
    id += urlAlphabet[bytes[size] & 63];
  }
  return id;
}, "nanoid");
export {
  customAlphabet,
  customRandom,
  nanoid,
  random,
  urlAlphabet
};
//# sourceMappingURL=nanoid.js.map
